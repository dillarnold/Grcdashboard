GRC Dashboard test CSVs
=======================
Open "GRC Dashboard.html" > gear menu > Import data, then load files into the matching slots.

1-sample-handoff/  The four GRC files from the design handoff. Import on their own to check the
                   acceptance figures (26 registrations, 25 submitted / 13 registered, ATOs 8/7/10,
                   POAMs 25 with all 25 Unmatched - the titles don't match the mapping aliases).

2-large-scale/     Synthetic scan data for stress testing (~100k assets). Use with the Registrations,
                   ATOs and POAMs from folder 1. Use THIS folder's SystemMapping.csv (it adds AWS accounts).
                   Import page setup:
                     Repositories.csv      -> Repositories.csv slot
                     + Tenable (Assets + EOL)      -> Assets.csv, EOL.csv
                     + Tenable (Vuln Detail)       -> VulnDetail.csv  (300k rows, 36 MB)
                     + RHACS                       -> RHACS.csv
                     + AWS (Full Inspector export) -> Inspector.csv, AWSMapping.csv, EKS.csv
                   Inspector reports ~10k rows skipped: CLOSED findings and Lambda rows, by design.
                   Includes an orphan repo/namespace/account so the Unattributed view has content.

3-edge-cases/
  SystemMapping_POAM_aliases_fixed.csv  Adds each system name as a POAM alias, so POAMs attribute
                                        to systems (populates POAM tiles, Top 5 and overdue counts).
  POAMs_missing_DueDate.csv             Should show red "Missing required column: Due".
  POAMs_messy.csv                       Unknown status ("In Progress", flagged, treated as open), quoted
                                        newline, ISO and long dates, a title matching nothing, and a
                                        blank Due Date row (skipped: 4 valid of 5).
  Registrations_BOM_duplicates.csv      UTF-8 BOM, a duplicated registration (first row wins) and a
                                        Rejected system.
  AWS_ContainerInventory.csv, AWS_EC2Inventory.csv, AWS_AccountInventory.csv
                                        AWS "Targeted CSVs" import style (switch the AWS environment
                                        to Targeted CSVs). Images with 0 deployed tasks/pods are dormant.
  Tenable_VulnDetail_small.csv          EOL rule checks: only eol-os.corp is EOL (date + cpe:/o:);
                                        eol-app.corp (application CPE) and no-date.corp (N/A) are not.
                                        dup.corp has one critical (same plugin twice); one IP-only asset.
